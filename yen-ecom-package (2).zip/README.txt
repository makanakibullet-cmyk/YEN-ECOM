YEN ECOM - HOW TO PUT THE SITE (AND THE APPLICATION FORM) LIVE

The application form sends to Formspree, which only works when the page
is hosted on a real website (it is blocked inside the Claude preview).

FASTEST (about 1 minute, free):
1. Unzip this folder.
2. Go to https://app.netlify.com/drop
3. Drag the whole unzipped folder onto the page.
4. Open the link Netlify gives you and send a test application.

Other free options: Vercel, Cloudflare Pages, GitHub Pages.

BEFORE YOU GO LIVE, edit index.html and replace:
- https://wa.me/10000000000   -> your WhatsApp link (wa.me/234XXXXXXXXXX)
- https://discord.gg/yourinvite -> your Discord invite

EMAIL NOTIFICATIONS (Formspree dashboard):
- Confirm your email when Formspree asks (first submission).
- Open the form -> make sure email notifications are ON.
- Check your spam folder for the first notification.
